<?php
/**
 * Helper functions: editable-content accessors, small utilities.
 *
 * Every editable field on the site resolves through one of these so the
 * templates stay clean and the Customizer stays the single source of truth.
 *
 * @package ma-lumiere
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get a theme mod with a sensible default.
 *
 * @param string $key     Mod key.
 * @param mixed  $default Fallback value.
 * @return mixed
 */
function ml_mod( $key, $default = '' ) {
	return get_theme_mod( $key, $default );
}

/**
 * Clinic name — falls back to the WordPress site name.
 *
 * @return string
 */
function ml_clinic_name() {
	$name = ml_mod( 'ml_clinic_name', 'MA LUMIÈRE' );
	return $name ? $name : get_bloginfo( 'name' );
}

/**
 * Clinic address (editable in Customizer).
 *
 * @return string
 */
function ml_clinic_address() {
	return ml_mod( 'ml_clinic_address', 'Shop no. 117 1st floor Ma lumiere clinic , Vasudev sky high , Kanakia  Rd, Om Ram Sagar phase 1 . beverly park, mira rd east 401105' );
}

/**
 * Clinic phone number.
 *
 * @return string
 */
function ml_clinic_phone() {
	return ml_mod( 'ml_clinic_phone', '9987802355' );
}

/**
 * Clinic email address.
 *
 * @return string
 */
function ml_clinic_email() {
	return ml_mod( 'ml_clinic_email', 'malumiere2026@gmail.com' );
}

/**
 * Clinic WhatsApp number.
 *
 * @return string
 */
function ml_clinic_whatsapp() {
	return ml_mod( 'ml_clinic_whatsapp', '9987802355' );
}

/**
 * Clinic opening hours (multi-line, editable in Customizer).
 *
 * @return string
 */
function ml_clinic_hours() {
	return ml_mod( 'ml_clinic_hours', "Tuesday – Saturday · 12:00 pm – 9:00 pm\nSunday · 12:00 pm – 5:00 pm\nMonday · Closed" );
}

/**
 * Doctor display name.
 *
 * @return string
 */
function ml_doctor_name() {
	return ml_mod( 'ml_doctor_name', 'Dr. Rishita Ray' );
}

/**
 * Doctor qualifications.
 *
 * @return string
 */
function ml_doctor_qualifications() {
	return ml_mod( 'ml_doctor_qualifications', 'Founder & Aesthetic Physician, Ma Lumière' );
}

/**
 * Doctor biography (rich text).
 *
 * @return string
 */
function ml_doctor_bio() {
	$default = '<p>I believe good aesthetic care begins with understanding the skin — not simply choosing a procedure.</p>'
		. '<p>I am Dr. Rishita Ray, an Aesthetic Physician with a background in modern aesthetic medicine and a special interest in skin health, acne, acne scarring and pigmentation.</p>'
		. '<p>My approach brings together medical understanding, clinical assessment and aesthetic precision. From managing persistent skin concerns to planning advanced aesthetic treatments, I believe every face and every skin type deserves an individualised approach.</p>'
		. '<p>At Ma Lumière, I founded the clinic around a simple philosophy: diagnosis first, procedures second.</p>'
		. '<p>I believe in understanding the underlying concern, setting realistic expectations and recommending treatments based on individual needs — never procedures for the sake of procedures.</p>'
		. '<p>Whether the goal is healthier skin, improved texture, scar management or subtle facial rejuvenation, my focus is on thoughtful treatment planning, natural-looking outcomes and care that evolves with you.</p>'
		. '<p>Because good aesthetic medicine isn’t about changing who you are. It’s about helping you feel comfortable in your own skin.</p>';
	return wp_kses_post( ml_mod( 'ml_doctor_bio', $default ) );
}

/**
 * Doctor areas of expertise, as array.
 *
 * @return array
 */
function ml_doctor_expertise() {
	$raw = ml_mod( 'ml_doctor_expertise', '' );
	if ( is_array( $raw ) ) {
		return array_filter( array_map( 'trim', $raw ) );
	}
	return array_values( array_filter( array_map( 'trim', explode( ',', (string) $raw ) ) ) );
}

/**
 * Doctor image attachment ID.
 *
 * @return int
 */
function ml_doctor_image_id() {
	return (int) ml_mod( 'ml_doctor_image', 0 );
}

/**
 * Hero image attachment ID.
 *
 * @return int
 */
function ml_hero_image_id() {
	return (int) ml_mod( 'ml_hero_image', 0 );
}

/**
 * Whether an attachment's file is actually present on this server.
 *
 * A media-library URL is only as reliable as the uploads directory behind it.
 * Hosts that deploy code but not `wp-content/uploads` keep the attachment rows
 * in the database while the files 404, which renders as broken-image icons.
 * Checking the file lets templates fall back to artwork bundled with the theme.
 *
 * @param int $attachment_id Attachment ID.
 * @return bool
 */
function ml_attachment_is_deployed( $attachment_id ) {
	$attachment_id = (int) $attachment_id;

	if ( ! $attachment_id ) {
		return false;
	}

	$file = get_attached_file( $attachment_id );

	return $file && file_exists( $file );
}

/**
 * URL of the theme-bundled photo for a treatment, keyed by its slug.
 *
 * @param int $post_id Treatment post ID. Defaults to the current post.
 * @return string Empty string when no bundled photo exists.
 */
function ml_treatment_fallback_image_url( $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$slug    = $post_id ? get_post_field( 'post_name', $post_id ) : '';

	if ( ! $slug ) {
		return '';
	}

	$relative = 'assets/images/treatments/' . sanitize_file_name( $slug ) . '.jpg';
	$file     = ML_THEME_DIR . '/' . $relative;

	if ( ! is_readable( $file ) ) {
		return '';
	}

	return ML_THEME_URI . '/' . $relative . '?v=' . ml_asset_version( $relative );
}

/**
 * Image URL for a treatment: media library when the file is deployed, else the
 * bundled photo shipped with the theme.
 *
 * @param int    $post_id Treatment post ID. Defaults to the current post.
 * @param string $size    Registered image size.
 * @return string Empty string when neither source is available.
 */
function ml_treatment_image_url( $post_id = 0, $size = 'ml-card' ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$thumb   = $post_id ? get_post_thumbnail_id( $post_id ) : 0;

	if ( ml_attachment_is_deployed( $thumb ) ) {
		$url = wp_get_attachment_image_url( $thumb, $size );
		if ( $url ) {
			return $url;
		}
	}

	return ml_treatment_fallback_image_url( $post_id );
}

/**
 * Print a treatment image, preferring the media library and falling back to
 * the bundled photo.
 *
 * @param int    $post_id Treatment post ID. Defaults to the current post.
 * @param string $size    Registered image size.
 * @param array  $attr    Extra attributes: class, alt, loading, eager.
 * @return bool True when an image was printed.
 */
function ml_treatment_image( $post_id = 0, $size = 'ml-card', $attr = array() ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$thumb   = $post_id ? get_post_thumbnail_id( $post_id ) : 0;
	$title   = $post_id ? wp_strip_all_tags( get_the_title( $post_id ) ) : '';

	$attr    = wp_parse_args(
		$attr,
		array(
			'class'   => '',
			'alt'     => $title ? $title : 'Ma Lumière',
			'loading' => 'lazy',
		)
	);

	if ( ml_attachment_is_deployed( $thumb ) ) {
		echo wp_get_attachment_image(
			$thumb,
			$size,
			false,
			array(
				'class'   => $attr['class'],
				'alt'     => $attr['alt'],
				'loading' => $attr['loading'],
			)
		);
		return true;
	}

	$url = ml_treatment_fallback_image_url( $post_id );

	if ( ! $url ) {
		return false;
	}

	printf(
		'<img src="%1$s" class="%2$s" alt="%3$s" loading="%4$s" decoding="async" />',
		esc_url( $url ),
		esc_attr( $attr['class'] ),
		esc_attr( $attr['alt'] ),
		esc_attr( $attr['loading'] )
	);

	return true;
}

/**
 * Hero image URL: the Customizer image when it is deployed, otherwise the
 * portrait bundled with the theme.
 *
 * @param string $size Registered image size.
 * @return string
 */
function ml_hero_image_url( $size = 'ml-portrait' ) {
	$relative = 'assets/images/hero.jpg';

	if ( is_readable( ML_THEME_DIR . '/' . $relative ) ) {
		return ML_THEME_URI . '/' . $relative . '?v=' . ml_asset_version( $relative );
	}

	return '';
}

/**
 * Hero background image URL: the Customizer image when it is deployed,
 * otherwise the wide photo bundled with the theme.
 *
 * The bundled fallback is assets/images/hero-bg.jpg (a wide clinic/laser
 * scene). Its filemtime is appended to the URL so replacing the file always
 * produces a new cache-busted URL instead of reusing a cached image.
 *
 * @return string Empty string when neither source is available.
 */
function ml_hero_background_image_url() {
	$image_id = (int) ml_mod( 'ml_hero_background_image', 0 );

	if ( ml_attachment_is_deployed( $image_id ) ) {
		$url = wp_get_attachment_image_url( $image_id, 'full' );
		if ( $url ) {
			return $url;
		}
	}

	$relative = 'assets/images/hero-bg.jpg';

	if ( is_readable( ML_THEME_DIR . '/' . $relative ) ) {
		return ML_THEME_URI . '/' . $relative . '?v=' . ml_asset_version( $relative );
	}

	return '';
}

/**
 * Editorial image URLs for treatment layouts.
 *
 * Starts with the site hero portrait, then large media-library images that
 * are not used as a treatment's featured image. This keeps the alternating
 * treatment rows on-brand instead of borrowing another treatment's photo.
 *
 * @param int $limit Maximum number of images.
 * @return array
 */
function ml_treatment_editorial_images( $limit = 2 ) {
	static $pool = null;

	if ( null === $pool ) {
		$pool    = array();
		$hero_id = ml_hero_image_id();

		if ( ml_attachment_is_deployed( $hero_id ) ) {
			$hero_url = wp_get_attachment_image_url( $hero_id, 'large' );
			if ( $hero_url ) {
				$pool[] = $hero_url;
			}
		}

		$treatment_ids    = get_posts(
			array(
				'post_type'      => 'ml_treatment',
				'posts_per_page' => -1,
				'post_status'    => 'publish',
				'fields'         => 'ids',
			)
		);
		$treatment_thumbs = array();
		foreach ( $treatment_ids as $treatment_id ) {
			$thumb_id = get_post_thumbnail_id( $treatment_id );
			if ( $thumb_id ) {
				$treatment_thumbs[] = $thumb_id;
			}
		}

		$exclude    = array_filter( array_merge( array( $hero_id ), $treatment_thumbs ) );
		$candidates = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_mime_type' => 'image',
				'post_status'    => 'inherit',
				'posts_per_page' => 6,
				'fields'         => 'ids',
				'post__not_in'   => $exclude,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);

		foreach ( $candidates as $candidate_id ) {
			if ( ! ml_attachment_is_deployed( $candidate_id ) ) {
				continue;
			}
			$meta = wp_get_attachment_metadata( $candidate_id );
			if ( empty( $meta['width'] ) || empty( $meta['height'] ) || $meta['width'] < 900 || $meta['height'] < 600 ) {
				continue;
			}
			$url = wp_get_attachment_image_url( $candidate_id, 'large' );
			if ( $url && ! in_array( $url, $pool, true ) ) {
				$pool[] = $url;
			}
		}
	}

	return array_slice( $pool, 0, max( 0, (int) $limit ) );
}

/**
 * Find a published page by its template file.
 *
 * @param string $template Template file name.
 * @return WP_Post|null
 */
function ml_page_by_template( $template ) {
	$pages = get_pages(
		array(
			'meta_key'   => '_wp_page_template',
			'meta_value' => $template,
			'number'     => 1,
		)
	);
	return $pages ? $pages[0] : null;
}

/**
 * URL of a page using the given template, or the supplied fallback.
 *
 * @param string $template Template file name.
 * @param string $fallback Fallback URL.
 * @return string
 */
function ml_page_url_by_template( $template, $fallback = '#' ) {
	$page = ml_page_by_template( $template );
	return $page ? get_permalink( $page ) : $fallback;
}

/**
 * Render an arbitrary inline SVG icon by name.
 *
 * @param string $name Icon key.
 * @param string $size Icon size in px.
 * @return void
 */
function ml_icon( $name, $size = 22 ) {
	$icons = array(
		'care'        => '<path d="M12 2.7c-2.6 2.9-5.1 5.4-5.1 8.2a5.1 5.1 0 0 0 10.2 0c0-2.8-2.5-5.3-5.1-8.2Z"/>',
		'evidence'    => '<path d="M9.5 21h5M12 3v0M12 3a9 9 0 0 1 9 9v3l-2 2H5l-2-2v-3a9 9 0 0 1 9-9Z"/>',
		'advanced'    => '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M18.4 5.6l-2.8 2.8M8.4 15.6l-2.8 2.8"/>',
		'patient'     => '<circle cx="12" cy="8" r="3.6"/><path d="M5.5 21c.7-3.4 3.3-5 6.5-5s5.8 1.6 6.5 5"/>',
		'calendar'    => '<rect x="3.5" y="5" width="17" height="16" rx="2.5"/><path d="M3.5 10h17M8 2.5V7M16 2.5V7"/>',
		'phone'       => '<path d="M5 3.5h3l1.6 4-2.1 1.6a13 13 0 0 0 6.4 6.4l1.6-2.1 4 1.6v3a2 2 0 0 1-2.2 2A17.5 17.5 0 0 1 3 5.7 2 2 0 0 1 5 3.5Z"/>',
		'mail'        => '<rect x="3" y="5.5" width="18" height="13" rx="2"/><path d="m4 8 8 5.5L20 8"/>',
		'whatsapp'    => '<path d="M12 3a9 9 0 0 0-7.8 13.5L3 21l4.6-1.2A9 9 0 1 0 12 3Z"/><path d="M8.7 9.3c.3 2.4 2 4.2 4.4 4.6l1.4-1.1 2 1.4"/><path d="M8.7 9.3c.2 1.9 1.4 3.4 3.2 4.1"/>',
		'clock'       => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
		'marker'      => '<path d="M12 21c4.5-4.2 7-7.6 7-11a7 7 0 1 0-14 0c0 3.4 2.5 6.8 7 11Z"/><circle cx="12" cy="10" r="2.5"/>',
		'arrow-right' => '<path d="M4 12h15M13 6l6 6-6 6"/>',
		'plus'        => '<path d="M12 5v14M5 12h14"/>',
		'quote'       => '<path d="M9 7H5.5C4.7 7 4 7.7 4 8.5V12h5V8.5C9 7.7 8.3 7 9 7Z"/><path d="M4 12v3c0 1.1 2.5 2 5 2"/><path d="M19.5 7H16c-.8 0-1.5.7-1.5 1.5V12h5V8.5c0-.8-.7-1.5-1.5-1.5Z"/><path d="M14.5 12v3c0 1.1 2.5 2 5 2"/>',
		'grid'        => '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
		'flower'      => '<circle cx="12" cy="12" r="2.8"/><path d="M12 6.5a3.2 3.2 0 0 1 6.2 1 3.2 3.2 0 0 1-1.8 3.2A3.2 3.2 0 0 1 19 15.5a3.2 3.2 0 0 1-5.9-1.2 3.2 3.2 0 0 1-2.2 0A3.2 3.2 0 0 1 5 14.3a3.2 3.2 0 0 1 1.8-4.6A3.2 3.2 0 0 1 8.6 6.5 3.2 3.2 0 0 1 12 6.5Z"/>',
		'compare'     => '<rect x="3.5" y="4.5" width="17" height="15" rx="2"/><path d="M3.5 4.5 21 19M12 5v14M12 21l-2.5-2M12 20l1-.8"/>',
	);

	// start with light default if missing.
	if ( ! isset( $icons[ $name ] ) ) {
		return;
	}

	$stroke_round = 'stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" fill="none"';
	printf(
		'<svg width="%1$d" height="%1$d" viewBox="0 0 24 24" aria-hidden="true" focusable="false" %2$s>%3$s</svg>',
		(int) $size,
		$stroke_round,
		$icons[ $name ] // phpcs:ignore WordPress.Security.EscapeOutput -- static icon paths above.
	);
}

/**
 * Social profiles stored in the Customizer.
 *
 * @return array
 */
function ml_social_links() {
	$allowed = array( 'instagram', 'facebook', 'youtube', 'whatsapp' );
	$links   = array();
	foreach ( $allowed as $key ) {
		$url = ml_mod( 'ml_social_' . $key, '' );
		if ( $url ) {
			$links[ $key ] = $url;
		}
	}
	return $links;
}

/**
 * Is a legacy/SEO plugin that supersedes our light OG output active?
 *
 * @return bool
 */
function ml_has_seo_plugin() {
	return class_exists( 'RankMath' )
		|| defined( 'WPSEO_VERSION' )
		|| defined( 'AIOSEO_VERSION' );
}

/**
 * Fallback for the primary menu — used only until a menu is assigned.
 *
 * @return void
 */
function ml_primary_menu_fallback() {
	$cta_page = ml_page_url_by_template( 'page-templates/page-appointment.php' );
	echo '<ul class="menu">';
	printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( home_url( '/' ) ), esc_html__( 'Home', 'ma-lumiere' ) );
	printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( ml_page_url_by_template( 'page-templates/page-about.php' ) ), esc_html__( 'About', 'ma-lumiere' ) );
	printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( ml_page_url_by_template( 'page-templates/page-treatments.php', get_post_type_archive_link( 'ml_treatment' ) ) ), esc_html__( 'Treatments', 'ma-lumiere' ) );
	printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( ml_page_url_by_template( 'page-templates/page-contact.php' ) ), esc_html__( 'Contact', 'ma-lumiere' ) );
	printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( $cta_page ), esc_html__( 'Book Consultation', 'ma-lumiere' ) );
	echo '</ul>';
}

/**
 * Fallback for footer menu column.
 *
 * @return void
 */
function ml_footer_menu_fallback() {
	$pages = array(
		'page-templates/page-about.php'      => __( 'About', 'ma-lumiere' ),
		'page-templates/page-treatments.php' => __( 'Treatments', 'ma-lumiere' ),
		'page-templates/page-contact.php'    => __( 'Contact', 'ma-lumiere' ),
		'page-templates/page-appointment.php' => __( 'Appointments', 'ma-lumiere' ),
	);
	echo '<ul>';
	foreach ( $pages as $tpl => $label ) {
		$fallback = 'page-templates/page-contact.php' === $tpl ? '' : get_post_type_archive_link( 'ml_treatment' );
		printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( ml_page_url_by_template( $tpl, (string) $fallback ) ), esc_html( $label ) );
	}
	echo '</ul>';
}

/**
 * Simple excerpt with a wrapper.
 *
 * @param int|null $length Number of words.
 * @return void
 */
function ml_excerpt( $length = null ) {
	$text = get_the_excerpt();
	if ( $length ) {
		$text = wp_trim_words( $text, $length, '…' );
	}
	echo '<p class="card__excerpt">' . esc_html( $text ) . '</p>';
}